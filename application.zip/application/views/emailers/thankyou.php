<html>

<body style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#000;">
  <section style="width: 600px; margin:0 auto;">
    <div style="border:0;">
      <div style="text-align:center;">
        <img src="http://wohlig.co.in/hqemailerimg/5.png" alt="" width="100%;">
      </div>
      <div style="padding: 0px 25px 0px;">
        <div style="padding:10px 0">
          <p style="margin:15px 0px;"> Hey Happyness Torch-bearer,
          </p>
          <p style="margin:0 0 15px 0;">
            We hope your Happyness Quotient journey has been a pleasant one! </p>
          <p style="margin:0 0 15px 0;">
            All the questions of the tool have been answered by your employees.
          </p>
          <p style="margin:0 0 15px 0;">
            The team at Never Grow Up will now analyse the data and get back to you soon!
          </p>

          <p style="margin:0 0 15px 0;">
            Your journey doesn't end here. This is just the beginning.</p>
          <p style="margin:0 0 15px 0;">Have a look at how else we can help you! <a href="http://willnevergrowup.com/employeeengagement" target="_blank">Have a look at how else we can help you! </a></p>

          <p style="margin:0 0 15px 0;">Happy to help!</p>
          <p style="margin:0 0 15px 0;">
            Regards,
            <br> Team Never Grow Up
          </p>
          <hr style="border:1px dashed #000;margin: 28px 151px 0 0;">
          <p style="padding: 6px 0;margin:0px;">
            Note: This is a system generated email, do not respond to this.
          </p>
        </div>
      </div>
      <div style="padding-bottom:10px">
        <img src="http://wohlig.co.in/hqemailerimg/17.png" alt="" width="100%;">
      </div>
    </div>
  </section>
</body>

</html>
