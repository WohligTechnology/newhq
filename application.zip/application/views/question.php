
  <div class="container">
    <div class="padtop">
      <div class="row">
        <div class="col s6">
          <div class="col s3">
            <span class="c-span">Category name:</span>
          </div>
          <div class="col s9">
            <div class="cat-names"><?php print_r($lastpillardetail);?>
              <input type="text" name="name" value="<?php echo $lastpillardetail->name;?>">
            </div>
          </div>

        </div>
      </div>
      <div class="row">
        <div class="col s6">
          <div class="box-left">
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Question 1:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 1:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 2:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 3:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 4:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="btn-right pl52">
                  <button type="submit" class="btn-ch ">Change format </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col s6">
          <div class="box-left">
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Question 1:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 1:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 2:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 3:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 4:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="btn-right pl52">
                  <button type="submit" class="btn-ch ">Change format </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col s6">
          <div class="box-left">
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Question 1:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 1:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 2:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 3:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 4:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="btn-right pl52">
                  <button type="submit" class="btn-ch ">Change format </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col s6">
          <div class="box-left">
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Question 1:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 1:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 2:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 3:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="col s2">
                  <span class="c-span">Answer 4:</span>
                </div>
                <div class="col s9">
                  <div class="cat-names">
                    <input type="text" name="name">
                  </div>
                </div>

              </div>
            </div>
            <div class="row">
              <div class="col s12">
                <div class="btn-right pl52">
                  <button type="submit" class="btn-ch ">Change format </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col s12">
          <div class="text-center">

            <a class="waves-effect waves-light btn blue-btn">Next</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
